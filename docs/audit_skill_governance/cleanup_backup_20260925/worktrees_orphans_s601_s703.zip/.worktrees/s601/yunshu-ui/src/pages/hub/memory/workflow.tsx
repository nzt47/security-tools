/**
 * 工作流技能管理 —— 学习到的工作流列表与启停（本地确定性执行）
 * 数据源：/api/workflow-learning/workflows
 *
 * 说明：工作流技能 = 从历史交互学习/可视化编排的确定性工具步骤；
 * 命中后本地直接执行（skipped_llm），不消耗 LLM。与「LLM 技能」分开管理，
 * 见技能中心（LLM 技能 / 工作流技能 / 可视化编辑三个 Tab）。
 */
import { useEffect, useState } from 'react'
import { Play } from 'lucide-react'
import { Card, Loading, ErrorBox, DataTable, Badge, PageHeader, hubGet, hubPost, pickList } from '../components/ui'

interface Workflow {
  id: string
  name?: string
  pattern?: string
  enabled?: boolean
  match_count?: number
  converted_to_skill_id?: string
  [k: string]: unknown
}

/** 列表体（技能中心「工作流技能」Tab 复用；页面/中心各自提供外壳） */
export function MemoryWorkflowTable() {
  const [items, setItems] = useState<Workflow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [execMsg, setExecMsg] = useState('')

  const load = () => {
    setLoading(true)
    hubGet('/api/workflow-learning/workflows').then((r) => {
      setItems(pickList<Workflow>(r, 'items'))
      setLoading(false)
    }).catch((e) => { setError(String(e)); setLoading(false) })
  }

  useEffect(load, [])

  const toggle = async (id: string) => {
    try {
      await hubPost(`/api/workflow-learning/workflows/${id}/toggle`)
      load()
    } catch (e) { setError(String(e)) }
  }

  const exec = async (id: string, fallbackTask?: string) => {
    try {
      const r = await hubPost(`/api/workflow-learning/execute/${id}`, {
        task_text: fallbackTask || '执行该工作流',
      })
      setExecMsg(`执行结果：${JSON.stringify(r).slice(0, 120)}`)
    } catch (e) { setExecMsg(`执行失败：${e instanceof Error ? e.message : e}`) }
  }

  /** 工作流 → LLM 参考说明导出：把工作流步骤叙述成给 LLM 看的说明（markdown）。
      注意：此导出**不替代工作流本体**——原工作流仍在「工作流技能」Tab（本地执行
      免 LLM）；导出副本仅作 LLM 参考（skills-mgmt），不改变工作流的执行属性。
      满足质量门控(成功次数/置信度/ACTIVE)才可导出。 */
  const convert = async (wf: Workflow) => {
    try {
      const r = await hubPost<{ skill_id?: string; skill_name?: string; action?: string; error?: string; review?: { verdict?: string; status?: string }; digest?: { verdict?: string; status?: string } }>(
        `/api/workflow-learning/workflows/${wf.id}/convert-to-skill`,
        // 术语纪律（TASK-S0-01）：新参数 auto_review（评审语义；旧 auto_digest 由后端兼容）
        { force: false, auto_review: true },
      )
      if (r?.error) { setExecMsg(`导出失败：${r.error}`); return }
      const action = r?.action === 'already_converted' ? '已导出过' : '已导出为 LLM 参考'
      const review = r?.review ?? r?.digest  // 兼容旧服务端响应键 digest（≤1 minor）
      const verdictMsg = review?.verdict === 'block' ? '，评审存在阻断项(待人工复核)' : '，评审-评估通过'
      setExecMsg(`${action}「${r?.skill_name ?? wf.name ?? wf.id}」（skill_id=${r?.skill_id}）${verdictMsg}——本工作流仍保留在「工作流技能」Tab，本地执行免 LLM`)
      load()
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      setExecMsg(`导出失败：${msg}（未达质量门控时需先积累成功次数/置信度）`)
    }
  }

  return (
    <div>
      {error && <div className="mb-4"><ErrorBox message={error} /></div>}
      {execMsg && <div className="mb-4 rounded-lg border border-slate-800 bg-slate-900 px-4 py-2 text-sm text-cyan-400">{execMsg}</div>}
      {loading ? <Loading /> : (
        <Card>
          <DataTable
            data={items}
            keyField="id"
            columns={[
              { key: 'name', title: '工作流', render: (r) => <span className="text-slate-200">{String(r.name ?? r.pattern ?? r.id)}</span> },
              { key: 'match_count', title: '匹配数', render: (r) => <span className="font-mono">{String(r.match_count ?? '-')}</span> },
              { key: 'enabled', title: '状态', render: (r) => <Badge color={r.enabled ? 'green' : 'slate'}>{r.enabled ? '启用' : '停用'}</Badge> },
              {
                key: 'actions', title: '操作',
                render: (r) => (
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => exec(r.id, String(r.source_user_input ?? r.name ?? r.id ?? ''))} className="flex items-center gap-1 rounded-md bg-blue-600 px-3 py-1.5 text-xs text-white hover:bg-blue-500" title="立即执行该工作流">
                      <Play size={11} /> 执行
                    </button>
                    <button onClick={() => toggle(r.id)} className="rounded-md border border-slate-700 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800" title={r.enabled ? '停用该工作流' : '启用该工作流'}>
                      {r.enabled ? '停用' : '启用'}
                    </button>
                    <button
                      onClick={() => convert(r)}
                      className="flex items-center gap-1 rounded-md border border-emerald-800/70 px-3 py-1.5 text-xs text-emerald-300 hover:bg-emerald-950/40"
                      title={
                        r.converted_to_skill_id
                          ? `已导出 LLM 参考 ${r.converted_to_skill_id}（再次点击返回既有参考）`
                          : '把工作流步骤导出为 LLM 参考说明（markdown，skills-mgmt）——不替代本工作流，本工作流仍本地执行免 LLM'
                      }
                    >
                      导出为 LLM 参考
                    </button>
                  </div>
                ),
              },
            ]}
          />
        </Card>
      )}
    </div>
  )
}

export default function MemoryWorkflow() {
  return (
    <div className="p-6">
      <PageHeader title="工作流技能" description="从历史交互中学习、本地确定性执行的工作流" />
      <MemoryWorkflowTable />
    </div>
  )
}
