/**
 * 工作台全局状态（Zustand）
 * ------------------------------------------------
 * 职责分层：
 *  - layout   ：Mosaic 布局树 —— 唯一持久化字段（LocalStorage）
 *  - messages ：对话消息，含流式增量（内存态）
 *  - thinking ：右侧"思考过程"面板的推理/工具事件流
 * 持久化仅针对 layout，借助 persist 中间件 + sanitizeLayout 防御脏数据。
 */
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { MosaicNode } from 'react-mosaic-component';
import { DEFAULT_LAYOUT, LAYOUT_STORAGE_KEY, sanitizeLayout, type PanelId } from '../lib/mosaic';
import { createChatStream, type ThinkingStatus } from '../lib/sse';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
  status?: 'streaming' | 'done' | 'error';
}

export interface ThinkingEvent {
  id: string;
  title: string;
  detail?: string;
  status: ThinkingStatus;
  at: number;
}

interface LayoutStore {
  layout: MosaicNode<PanelId> | null;
  messages: ChatMessage[];
  thinking: ThinkingEvent[];
  streaming: boolean;
  activeStreamId: string | null;
  /** 历史问话跳转定位：需要滚动/高亮的消息 ID（由 ChatPanel 消费并在动画后清空） */
  highlightMsgId: string | null;
  /**
   * 当前激活的会话 ID（会话任务页多会话视图的单一数据源）。
   * sendMessage 据此把流式请求归属到该会话（后端落盘持久化）；
   * 非会话页（独立窗口/单会话遗留场景）保持 null → 走后端全局当前会话。
   */
  activeSessionId: string | null;

  setLayout: (next: MosaicNode<PanelId> | null) => void;
  resetLayout: () => void;
  sendMessage: (text: string) => Promise<void>;
  stopStreaming: () => void;
  clearConversation: () => void;
  /** 从后端会话加载历史消息（messages 为空时使用，刷新后恢复对话） */
  loadSessionHistory: (sessionId: string, opts?: { force?: boolean }) => Promise<void>;
  /** 请求滚动定位到某条消息（由 ChatPanel 渲染层消费，动画结束后自动置空） */
  setHighlightMsg: (id: string | null) => void;
  /** 设置当前激活会话（会话切换/新建/删除后由页面调用） */
  setActiveSession: (id: string | null) => void;
}

// 仅暴露给 persist 的字段（layout 之外的动态数据不做本地持久化）
type PersistedState = Pick<LayoutStore, 'layout'>;

// 模拟流的中止控制器（非响应式，仅控制生成器）
let abortController: AbortController | null = null;

// ─── 流式过程日志订阅（供 ChatPanel 打印排查断流/乱序，非响应式） ───
export type StreamLogKind = 'send' | 'thinking' | 'chunk' | 'done' | 'error' | 'abort';

export interface StreamLogEvent {
  kind: StreamLogKind;
  ts: number;
  streamId?: string;
  seq?: number;
  text?: string;
  accumulated?: number;
  title?: string;
  status?: ThinkingStatus;
  detail?: string;
}

type StreamLogListener = (e: StreamLogEvent) => void;

const streamLogListeners = new Set<StreamLogListener>();

/** 订阅流式过程日志，返回取消订阅函数 */
export function subscribeStreamLog(listener: StreamLogListener): () => void {
  streamLogListeners.add(listener);
  return () => streamLogListeners.delete(listener);
}

function emitStreamLog(event: StreamLogEvent) {
  streamLogListeners.forEach((fn) => fn(event));
}

export const useLayoutStore = create<LayoutStore>()(
  persist(
    (set, get) => ({
      layout: null,
      messages: [],
      thinking: [],
      streaming: false,
      activeStreamId: null,
      highlightMsgId: null,
      activeSessionId: null,

      setLayout: (next) => set({ layout: next }),

      resetLayout: () => set({ layout: DEFAULT_LAYOUT }),

      sendMessage: async (text) => {
        const { streaming } = get();
        if (streaming || !text.trim()) return;

        const userMsg: ChatMessage = {
          id: `user-${Date.now()}`,
          role: 'user',
          content: text.trim(),
          createdAt: Date.now(),
          status: 'done',
        };
        const streamId = `asst-${Date.now()}`;
        const assistantMsg: ChatMessage = {
          id: streamId,
          role: 'assistant',
          content: '',
          createdAt: Date.now(),
          status: 'streaming',
        };

        set((state) => ({
          messages: [...state.messages, userMsg, assistantMsg],
          streaming: true,
          activeStreamId: streamId,
          thinking: [],
        }));

        emitStreamLog({ kind: 'send', ts: Date.now(), streamId, detail: text });

        abortController = new AbortController();
        const upsertThinking = (evt: {
          id: string;
          title: string;
          detail?: string;
          status: ThinkingStatus;
        }) => {
          emitStreamLog({
            kind: 'thinking',
            ts: Date.now(),
            streamId,
            title: evt.title,
            status: evt.status,
            detail: evt.detail,
          });
          set((state) => {
            const nextEvent: ThinkingEvent = { ...evt, at: Date.now() };
            const exists = state.thinking.some((t) => t.id === evt.id);
            return {
              thinking: exists
                ? state.thinking.map((t) => (t.id === evt.id ? nextEvent : t))
                : [...state.thinking, nextEvent],
            };
          });
        };

        let accumulated = 0;
        try {
          // 携带当前激活会话 ID → 后端按该会话落盘（多会话持久化关键）
          const sessionId = get().activeSessionId ?? undefined;
          for await (const event of createChatStream(
            text,
            abortController.signal,
            { sessionId },
          )) {
            if (event.type === 'chunk') {
              accumulated += event.text.length;
              emitStreamLog({
                kind: 'chunk',
                ts: Date.now(),
                streamId,
                seq: event.seq,
                text: event.text,
                accumulated,
              });
              set((state) => ({
                messages: state.messages.map((m) =>
                  m.id === streamId ? { ...m, content: m.content + event.text } : m,
                ),
              }));
            } else if (event.type === 'thinking') {
              upsertThinking(event);
            } else if (event.type === 'done') {
              break;
            }
          }
          emitStreamLog({ kind: 'done', ts: Date.now(), streamId, accumulated });
          set((state) => ({
            messages: state.messages.map((m) =>
              m.id === streamId ? { ...m, status: 'done' as const } : m,
            ),
            streaming: false,
            activeStreamId: null,
          }));
        } catch (err) {
          // 主动停止（AbortError）不视为错误，保留已生成内容
          const isAbort = err instanceof DOMException && err.name === 'AbortError';
          emitStreamLog({
            kind: isAbort ? 'abort' : 'error',
            ts: Date.now(),
            streamId,
            accumulated,
            detail: err instanceof Error ? err.message : String(err),
          });
          set((state) => ({
            messages: state.messages.map((m) =>
              m.id === streamId
                ? { ...m, status: (isAbort ? 'done' : 'error') }
                : m,
            ),
            streaming: false,
            activeStreamId: null,
          }));
        } finally {
          abortController = null;
        }
      },

      stopStreaming: () => {
        abortController?.abort();
      },

      clearConversation: () => {
        abortController?.abort();
        set({ messages: [], thinking: [], streaming: false, activeStreamId: null, highlightMsgId: null });
      },

      loadSessionHistory: async (sessionId, opts) => {
        // 仅当当前无消息时加载，避免覆盖进行中的对话；force=true 时无视该保护
        // （历史问话删除后需强制同步被删条目的会话视图）
        if (!sessionId) return;
        if (get().messages.length > 0 && !opts?.force) return;
        try {
          const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/messages`);
          if (!res.ok) return;
          // 竞态防护：加载期间用户已切到其他会话 → 丢弃过期响应
          const activeNow = get().activeSessionId;
          if (activeNow && activeNow !== sessionId) return;
          const hist = (await res.json()) as { role?: string; content?: string; timestamp?: string }[];
          if (activeNow && activeNow !== sessionId) return;
          if (!Array.isArray(hist) || hist.length === 0) {
            if (opts?.force) set({ messages: [] });
            return;
          }
          const loaded: ChatMessage[] = hist
            .filter((m) => m.content)
            .map((m, i) => ({
              id: `hist-${sessionId}-${i}`,
              role: (m.role === 'assistant' ? 'assistant' : 'user') as ChatMessage['role'],
              content: String(m.content),
              createdAt: m.timestamp ? new Date(m.timestamp).getTime() : Date.now(),
              status: 'done' as const,
            }));
          if (loaded.length > 0) set({ messages: loaded });
        } catch {
          // 历史加载失败静默（不影响新对话）
        }
      },

      setHighlightMsg: (id) => set({ highlightMsgId: id }),

      setActiveSession: (id) => {
        // 会话切换/新建/删除后由页面调用；只更新归属标记，不清空消息流
        // （消息流的清空由页面 clearConversation + loadSessionHistory 负责）
        set({ activeSessionId: id });
      },
    }),
    {
      name: LAYOUT_STORAGE_KEY,
      version: 1,
      storage: createJSONStorage(() => localStorage),
      partialize: (state): PersistedState => ({ layout: state.layout }),
      // 反序列化校验：非法布局回退默认，保证"刷新不丢布局"且不白屏
      merge: (persisted, current) => {
        const saved = persisted as Partial<PersistedState>;
        return {
          ...current,
          layout: saved.layout ? sanitizeLayout(saved.layout) ?? null : null,
        };
      },
    },
  ),
);
