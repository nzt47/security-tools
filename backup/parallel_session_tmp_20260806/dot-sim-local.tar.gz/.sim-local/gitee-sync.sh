#!/usr/bin/env bash
# 模拟 GitLab CI gitee-sync job（stage: release），与 .gitlab-ci.yml 脚本保持一致
set -euo pipefail
cd /c/Users/Administrator/agent
VERSION="${CI_COMMIT_TAG:-$version}"
echo "===== gitee-sync 开始 ====="
echo "==> 版本号: $VERSION"
echo "==> GITEE_TOKEN 已配置（长度 ${#GITEE_TOKEN}）"
MAX_RETRY=3
RETRY=1
while :; do
  echo "--- Gitee 同步尝试 $RETRY/$MAX_RETRY (create_gitee_release.ps1) ---"
  pwsh -NoProfile -File scripts/create_gitee_release.ps1 \
    -TagName "$VERSION" \
    -Title "Release $VERSION" \
    -BodyFile notes.md && {
    echo "==> Gitee Release 同步成功:"
    echo "    https://gitee.com/${CI_PROJECT_PATH}/releases/$VERSION"
    break
  }
  RC=$?
  if [ "$RETRY" -ge "$MAX_RETRY" ]; then
    echo "::error::Gitee 同步重试 $MAX_RETRY 次均失败（最后一次退出码 $RC），触发告警 job" >&2
    exit 1
  fi
  echo "==> Gitee 同步失败（退出码 $RC），10s 后第 $((RETRY+1)) 次重试..."
  RETRY=$((RETRY+1))
  sleep 10
done
echo "===== gitee-sync 结束 (exit 0) ====="
