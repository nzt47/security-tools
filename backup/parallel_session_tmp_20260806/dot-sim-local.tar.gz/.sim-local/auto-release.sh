#!/usr/bin/env bash
# 模拟 GitLab CI auto-release job（stage: release），与 .gitlab-ci.yml 脚本保持一致
set -euo pipefail
cd /c/Users/Administrator/agent
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python   # Windows 本地用 python
VERSION="${CI_COMMIT_TAG:-$version}"
echo "===== auto-release 开始 ====="
echo "==> 版本号: $VERSION"
echo "==> 触发方式: $CI_PIPELINE_SOURCE"
echo "==> Pipeline: $CI_PIPELINE_URL"
PREV=$(git tag --sort=-creatordate | sed -n '2p')
echo "==> 上一版本 tag: $PREV"
echo "--- 变更提交清单 (${PREV}..HEAD) ---"
git log --oneline "${PREV}..HEAD"
echo "==> 提交总数: $(git log --oneline "${PREV}..HEAD" | wc -l)"
$PY scripts/update_changelog.py --version "$VERSION" --prev-tag "$PREV" --out notes.md
echo "==> notes.md 已生成: $(wc -l < notes.md) 行"

echo ""
echo "===== 创建 GitHub Release (REST API) ====="
if [ -z "${GH_TOKEN:-}" ]; then
  echo "==> [跳过] GH_TOKEN 未配置（仅生成发布备注，不创建 Release）"
else
  echo "==> GH_TOKEN 已配置（长度 ${#GH_TOKEN}），POST /repos/${CI_PROJECT_PATH}/releases"
  MAX_RETRY=3
  RETRY=1
  while :; do
    echo "--- GitHub Release 创建尝试 $RETRY/$MAX_RETRY ---"
    BODY=$(python3 -c "import json,sys;print(json.dumps(open(sys.argv[1],encoding='utf-8').read()))" notes.md)
    CODE=$(curl -s -o gh_resp.json -w '%{http_code}' -X POST \
      "https://api.github.com/repos/${CI_PROJECT_PATH}/releases" \
      -H "Authorization: Bearer $GH_TOKEN" \
      -H "Accept: application/vnd.github+json" \
      -d "{\"tag_name\":\"$VERSION\",\"name\":\"Release $VERSION\",\"body\":$BODY}")
    echo "==> GitHub API 响应: HTTP $CODE"
    if [ "$CODE" -lt 400 ]; then
      echo "==> GitHub Release 创建成功:"
      echo "    https://github.com/${CI_PROJECT_PATH}/releases/tag/$VERSION"
      rm -f gh_resp.json
      break
    fi
    echo "==> API 响应体: $(head -c 300 gh_resp.json)"
    if [ "$CODE" -eq 409 ] || [ "$CODE" -eq 422 ]; then
      echo "::error::HTTP $CODE: 该 tag 已存在 Release（幂等冲突，重试无意义），需改用编辑接口" >&2
      rm -f gh_resp.json
      exit 1
    fi
    if [ "$RETRY" -ge "$MAX_RETRY" ]; then
      echo "::error::GitHub Release 创建重试 $MAX_RETRY 次均失败，触发告警 job" >&2
      rm -f gh_resp.json
      exit 1
    fi
    echo "==> 10s 后重试..."
    RETRY=$((RETRY+1))
    sleep 10
  done
fi
echo ""
echo "===== auto-release 结束 (exit 0) ====="
