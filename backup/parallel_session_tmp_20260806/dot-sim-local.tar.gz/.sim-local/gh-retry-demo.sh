#!/usr/bin/env bash
# 演示 GitHub Release 创建失败的重试逻辑（与 .gitlab-ci.yml auto-release 脚本一致）
# 用法: gh-retry-demo.sh <API_URL>  例: gh-retry-demo.sh http://127.0.0.1:9801/releases
set -euo pipefail
cd /c/Users/Administrator/agent
API="$1"
VERSION="v1.0.2"
GH_TOKEN="fake-token"                     # 演示用假 token（mock 不校验）
SLEEP="${SLEEP:-10}"                      # 演示时可设 SLEEP=1 加速
PY=python3; command -v python3 >/dev/null 2>&1 || PY=python
MAX_RETRY=3
RETRY=1
while :; do
  echo "--- GitHub Release 创建尝试 $RETRY/$MAX_RETRY ---"
  BODY=$($PY -c "import json,sys;print(json.dumps(open(sys.argv[1],encoding='utf-8').read()))" notes.md)
  CODE=$(curl -s -o gh_resp.json -w '%{http_code}' -X POST "$API" \
    -H "Authorization: Bearer $GH_TOKEN" \
    -H "Accept: application/vnd.github+json" \
    -d "{\"tag_name\":\"$VERSION\",\"name\":\"Release $VERSION\",\"body\":$BODY}")
  echo "==> GitHub API 响应: HTTP $CODE"
  if [ "$CODE" -lt 400 ]; then
    echo "==> GitHub Release 创建成功:"
    echo "    http://127.0.0.1:9801/releases/tag/$VERSION"
    rm -f gh_resp.json
    exit 0
  fi
  echo "==> API 响应体: $(head -c 300 gh_resp.json)"
  if [ "$CODE" -eq 409 ] || [ "$CODE" -eq 422 ]; then
    echo "::error::HTTP $CODE: 该 tag 已存在 Release（幂等冲突，重试无意义），需改用编辑接口" >&2
    rm -f gh_resp.json
    exit 1
  fi
  if [ "$RETRY" -ge "$MAX_RETRY" ]; then
    echo "::error::GitHub Release 创建重试 $MAX_RETRY 次均失败，触发告警 job" >&2
    rm -f gh_resp.json
    exit 1
  fi
  echo "==> ${SLEEP}s 后重试..."
  RETRY=$((RETRY+1))
  sleep "$SLEEP"
done
