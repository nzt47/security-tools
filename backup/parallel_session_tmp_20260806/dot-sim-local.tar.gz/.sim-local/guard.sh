#!/usr/bin/env bash
# 模拟 GitLab CI guard job（stage: gate）
set -euo pipefail
cd /c/Users/Administrator/agent
export CI_COMMIT_TAG="${CI_COMMIT_TAG:-}"
VERSION="${CI_COMMIT_TAG:-$version}"
SKIP="false"
echo "===== [guard] stage: gate ====="
echo "==> 判定版本: $VERSION"
if [ -n "$VERSION" ] && git rev-parse -q --verify "refs/tags/$VERSION" >/dev/null 2>&1; then
  MSG=$(git log -1 --format=%s "$VERSION")
  echo "tag commit message: $MSG"
  if echo "$MSG" | grep -qiE '^release\(pypi\)'; then
    SKIP="true"
    echo "==> 子包发布 tag，跳过主项目自动发布"
  else
    echo "==> 非子包发布，放行"
  fi
else
  echo "==> 手动触发或 tag 本地不存在，默认放行"
fi
echo "SKIP=$SKIP" > guard.env
echo "===== guard.env ====="
cat guard.env
