"""本地 mock GitHub Releases API，用于演示重试逻辑（仅本地模拟，不触碰真实网络）"""
import http.server
import json
import os

PORT = int(os.environ.get("MOCK_PORT", "9801"))
counter = {"n": 0}


class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        counter["n"] += 1
        if "conflict" in self.path:
            code, payload = 409, {"message": "Validation Failed: tag already exists"}
        elif counter["n"] < 3:
            code, payload = 500, {"message": "Internal Server Error (simulated)"}
        else:
            code, payload = 201, {"html_url": f"http://127.0.0.1:{PORT}/releases/tag/v1.0.2"}
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


http.server.HTTPServer(("127.0.0.1", PORT), H).serve_forever()
